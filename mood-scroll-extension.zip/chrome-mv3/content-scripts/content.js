var content=function(){"use strict";var Qe=Object.defineProperty;var Ze=(P,M,H)=>M in P?Qe(P,M,{enumerable:!0,configurable:!0,writable:!0,value:H}):P[M]=H;var $=(P,M,H)=>Ze(P,typeof M!="symbol"?M+"":M,H);var he,fe;function P(i){return i}const M=[{id:"auto_scroll",emoji:"⏩",label:"Auto Scroll",matches:[],broadMatches:[]},{id:"brain_rot",emoji:"🧠💀",label:"Brain Rot",matches:["brain_rot","food_porn"],broadMatches:["brain_rot","food_porn","comedy"]},{id:"cooking",emoji:"🍳",label:"Cooking",matches:["cooking"],broadMatches:["cooking","food_porn"]},{id:"laugh",emoji:"😂",label:"Laugh",matches:["comedy"],broadMatches:["comedy","brain_rot"]},{id:"larp",emoji:"💎",label:"LARP",matches:["larp"],broadMatches:["larp","motivational","fitness"]},{id:"fitness",emoji:"💪",label:"Fitness",matches:["fitness"],broadMatches:["fitness","motivational"]},{id:"baddies",emoji:"💅",label:"Baddies",matches:["baddies"],broadMatches:["baddies"]},{id:"custom",emoji:"✨",label:"Custom",matches:[],broadMatches:[]}],H=new Set(["fyp","foryoupage","foryou","viral","trending","parati","xyzbca"]),Te={cooking:{keywords:["recipe","how to make","how to cook","ingredients:","preheat","simmer for","sauté","whisk together","fold in","minutes at","stir in","bake at"],hashtags:["cookingtiktok","easyrecipe","recipevideo","cookingclass","cheflife","kitchenhacks"]},educational:{keywords:["how to","tutorial","explained","tip:","did you know","pro tip","lesson","fact:","in this video"],hashtags:["learnontiktok","edutok","studytok","didyouknow","sciencetok","history","tutorial"]},comedy:{keywords:["skit","pov:","when you","when my","me when","tell me without telling me","pov when"],hashtags:["comedy","funny","humor","jokes","meme","lmao"]},fitness:{keywords:["shirtless","pump","pump cover","gym session","workout","deadlift","squat","bench press","chest day","back day","leg day","arm day","lifting","gainz","shredded","physique","natty","mens physique","bodybuilding","cutting","bulking","reps","sets","rep range","gym pr","six pack","aesthetic gym","gym flex","flexing muscle"],hashtags:["gymtok","fittok","fitness","gymrat","bodybuilding","physique","gainz","gym","gymflex","shredded","mensphysique","womensphysique","natty","lifting","fitfam","fitspo","workout","gymmotivation","gymlife","chestday","backday","legday","pumpcover","sixpack","aestheticgym","gymbros","gymtransformation"]},baddies:{keywords:["baddie","bad bitch","pretty privilege","glam","glow up","outfit of the day","ootd","fit check","feeling cute","baddie aesthetic","gym girl","fit girl","gym fit","how she walks","just girls"],hashtags:["baddie","baddies","baddietok","baddievibes","baddieaesthetic","badbitch","badbitchenergy","fitgirl","fitgirls","gymgirl","gymgirls","gymbaddie","glam","glamour","glammakeup","ootd","fashiongirl","fashionista","fitcheck","fitcheckdaily","glowup","glowupchallenge","instabaddie","baddiesonly","thatgirl","cleangirl","cleangirlaesthetic","softgirl","gymgirlaesthetic","gymgirlfit"]},motivational:{keywords:["grind","success","never give up","mindset","discipline","hustle","mentality"],hashtags:["motivation","sigma","mindset","success","entrepreneur","inspiration"]},brain_rot:{keywords:["skibidi","skibidi toilet","sigma","gigachad","gyatt","rizz","ohio","fanum","mewing","looksmax","looksmaxxing","subway surfers","minecraft parkour","ai voice","ai narrator","ai voiceover","peter griffin","family guy edit","stewie","spongebob edit","simpsons edit","anime edit","animeedit"],hashtags:["skibidi","skibiditoilet","brainrot","sigma","sigmaedit","sigmamale","gigachad","gyatt","rizz","ohio","fanumtax","mewing","looksmaxxing","aigenerated","aivoice","aivideo","aishorts","airelaxing","familyguy","familyguyedit","peterstewieedit","petergriffin","spongebob","spongebobedit","simpsonsedit","rickandmorty","phonk","phonky","phonkedit","phonkmusic","animeedit","animeedits","manhwa","manhwaedit","subwaysurfers","minecraftparkour","parkour","edit","edits","cope","slop","sloppost","ragebait"]},wholesome:{keywords:["rescued","wholesome","made my day","good news"],hashtags:["wholesome","cute","feelgood","adoption","kindness"]},food_porn:{keywords:[],hashtags:["foodporn","food","yummy","tasty","foodie"]},larp:{keywords:["lamborghini","lambo","ferrari","mclaren","rolls royce","bentley","aventador","huracan","urus","g wagon","g-wagon","g63","rolex","patek philippe","audemars piguet","richard mille","birkin","louis vuitton","hermes bag","gucci flex","secured the bag","first million","made my first million","luxury lifestyle","i'm rich","i'm so rich","rich kid","private jet","mansion tour","penthouse tour","andrew tate","tristan tate","iman gadzhi","tai lopez","grant cardone","alpha male","sigma grindset","high value man"],hashtags:["lambo","lamborghini","ferrari","mclaren","bentley","rollsroyce","supercar","supercars","exoticcars","exoticcar","sportscar","sportscars","luxurycar","luxurycars","aventador","huracan","urus","gwagon","g63","rolex","rolexwatch","patekphilippe","audemarspiguet","richardmille","luxurywatches","birkin","hermesbirkin","louisvuitton","gucciflex","luxurylifestyle","richlife","millionairelifestyle","billionairelifestyle","millionaire","billionaire","andrewtate","tristantate","sigmamale","alphamale","sigmagrindset","sigmaedit","highvalueman","imanagadzhi","tailopez","grantcardone","flex","moneyflex","getrichquick","privatejet","oldmoney","newmoney","hustlegrindset"]},startup:{keywords:["startup","founder","y combinator"," yc ","seed round","series a","mvp","product market fit","pmf","fundraising","pitch deck","launching","building in public","saas","indie hacker"],hashtags:["startup","startups","founder","founders","ycombinator","yc","startuplife","entrepreneur","saas","indiehackers","buildinpublic","techstartup","siliconvalley","techtok"]}};function Ce(i,o,l){const m=o.map(x=>x.toLowerCase().replace(/^#/,"")).filter(x=>!H.has(x)),k=((i||"")+" "+(l||"")).toLowerCase(),b={};for(const[x,v]of Object.entries(Te)){let y=0;for(const W of v.keywords)k.includes(W)&&(y+=2);for(const W of v.hashtags)m.includes(W)&&(y+=3);y>0&&(b[x]=y)}const A=Object.entries(b).sort((x,v)=>v[1]-x[1]);if(!A.length)return{category:null,confidence:0};const[I,F]=A[0];return{category:I,confidence:Math.min(F/6,.95)}}const Le={matches:["https://www.tiktok.com/*"],main(){const i={videoSelector:"video",itemSelector:'[data-e2e="recommend-list-item-container"]',captionSelector:'[data-e2e="video-desc"]',audioSelector:'[data-e2e="video-music"]',creatorSelector:'a[href^="/@"]',likeIconSelector:'[data-e2e="like-icon"]',likeAriaSelector:'button[aria-label*="Like" i]',scrollContainerId:"column-list-container",minVideoHeight:200,decisionIntervalMs:1500,tickIntervalMs:500,likeDelayMinMs:4e3,likeDelayJitterMs:3e3,likeProbability:.55,likeRateLimitWindowMs:36e5,likeRateLimitMax:20};let o=null,l="",m=!0,k=!1,b=!1,A=0,I=null;const F=new Set,x=[];let v="training";const y=[],W=10,_e=.6,Re=.4,Ne={decisionIntervalMs:300,likeProbability:1,useFrames:!0},Oe={decisionIntervalMs:2500,likeProbability:.3,useFrames:!0},ce=()=>v==="training"?Ne:Oe,qe={brain_rot:2500,food_porn:4e3,baddies:5e3,comedy:5500,fitness:7e3,larp:7500,motivational:8e3,wholesome:7500,wind_down:9e3,cooking:1e4,news_politics:11e3,educational:13e3,startup:13e3,drama_storytime:15e3,other:6e3};function ze(e){return qe[e||"other"]||6e3}function be(e,t){const n=ze(e),r=t!=null&&t.duration&&isFinite(t.duration)&&t.duration>0?Math.floor(t.duration*1e3):0;if(r>0){const s=Math.max(2500,Math.floor(r*.92));return Math.min(n,s)}return n}let T=0,B=0;setInterval(()=>{if(T===0||!o||o==="auto_scroll")return;const e=R();if(!(!e||!e.currentSrc)){if(B>0&&e.currentTime+.5<B){console.log("[MoodScroll] video looped, advancing immediately"),T=0,B=0,q(e.currentSrc);return}if(e.duration&&e.currentTime>e.duration-.5){console.log("[MoodScroll] video about to loop, advancing now"),T=0,B=0,q(e.currentSrc);return}B=e.currentTime}},250);const ee=new Set(["larp","baddies","fitness","brain_rot"]),$e={startup:["dance","dancing","makeup","beauty","fashion","outfit","nails","hair","asmr","slime","satisfying","cat","cats","dog","dogs","pets","animals","food","foodporn","cooking","recipe","foodtok","restaurant","workout","gym","gymtok","fitness","bodybuilding","pov","skit","comedy","funny","meme","humor","jokes","prank","storytime","gossip","drama","tea","relationship","sports","football","basketball","soccer","nba","nfl","music","song","singing","dance challenge","lifehack","travel","wedding","gaming","minecraft","fortnite"],learn:["dance","makeup","beauty","fashion","outfit","nails","comedy","funny","meme","humor","jokes","pov","skit","asmr","slime","satisfying","prank","storytime","gossip","drama","tea","relationship","gaming","sports","wedding","travel"],cooking:["dance","dancing","makeup","beauty","fashion","outfit","nails","hair","workout","gym","fitness","bodybuilding","cardio","startup","business","finance","crypto","stocks","asmr","slime","sleep","gaming","minecraft","fortnite","sports","football","basketball"],laugh:["recipe","cooking","foodtok","workout","gym","fitness","cardio","tutorial","study","studytok","history","science","edu","startup","business","finance","investing","crypto","news","politics","asmr","sleep","wholesome"],hype:["asmr","slime","sleep","wholesome","cooking","recipe","foodtok","startup","tutorial","study","sad","cry","breakup","gossip","drama","storytime","news","politics","gaming"],wind_down:["workout","gym","fitness","cardio","hiit","hustle","grind","startup","business","finance","comedy","meme","prank","funny","news","politics","sports","gaming","fortnite","minecraft","dance challenge","shock","fight"],brain_rot:["startup","business","finance","tutorial","study","history","science","edu","learnontiktok","news","politics","documentary"],food_porn:["dance","workout","gym","startup","finance","tutorial","study","history","science","sports","gaming","news","politics","comedy","skit","pov"],larp:["cooking","recipe","foodtok","dance","dancing","makeup","beauty","nails","hair","comedy","meme","skit","prank","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics"],fitness:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics","comedy","meme","skit","prank","dance challenge"],baddies:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","news","politics","wholesome","family"]};chrome.storage.local.get(["currentMode","customDescription","autoEngage","sidekickActive"]).then(e=>{o=e.currentMode||null,l=e.customDescription||"",m=e.autoEngage!==!1,k=!!e.sidekickActive,k&&ye(),L()}),chrome.runtime.onMessage.addListener(e=>{e.type==="set_mode"&&(o=e.mode,I=null,me(),L()),e.type==="stop"&&(o=null,I=null,me(),L())});function ye(){if(document.getElementById("moodscroll-sidekick-css"))return;const e=document.createElement("style");e.id="moodscroll-sidekick-css",e.textContent=`
        /* HARD HIDES: all nav + header chrome */
        [data-e2e="nav-foryou"], [data-e2e="nav-following"], [data-e2e="nav-explore"],
        [data-e2e="nav-live"], [data-e2e="nav-shop"], [data-e2e="nav-profile"],
        [data-e2e="nav-upload"], [data-e2e="nav-more-menu"], [data-e2e="nav-search"],
        [data-e2e="search-box"], [data-e2e="search-box-button"],
        [data-e2e="top-login-button"], [data-e2e="top-right-action-bar-get-coin"],
        [data-e2e="tiktok-logo"],
        /* Right-side engagement column (like/comment/share/follow/save) */
        [data-e2e="like-icon"], [data-e2e="like-count"],
        [data-e2e="comment-icon"], [data-e2e="comment-count"],
        [data-e2e="share-icon"], [data-e2e="share-count"],
        [data-e2e="favorite-icon"], [data-e2e="favorite-count"],
        [data-e2e="feed-follow"], [data-e2e="video-author-avatar"],
        [data-e2e="more-menu-icon"], [data-e2e="see-more-icon"],
        /* Caption / music / desc overlays */
        [data-e2e="video-desc"], [data-e2e="video-music"], [data-e2e="capcut-tag"],
        [data-e2e^="desc-span"], [data-e2e="copyright"],
        /* Sidebars + the whole left column */
        [class*="DivSideNavContainer"], [class*="DivHeaderContainer"],
        [class*="DivLeftContainer"], [class*="DivSidebarContainer"],
        [class*="DivTabMenuContainer"], aside, header {
          display: none !important; width: 0 !important; height: 0 !important;
        }
        /* Compress horizontal margins so video fills the window */
        #column-list-container, [class*="DivColumnL"] {
          margin: 0 auto !important; padding: 0 !important;
        }
        body, html {
          background: #000 !important;
        }
        /* Strip TikTok's gradient overlays that darken the bottom of the video */
        [class*="DivBottomShadow"], [class*="DivVideoInfoContainer"],
        [class*="DivVideoCardContainer"] > div[class*="DivBottom"] {
          display: none !important;
        }
        /* Mood Scroll's own collapsed button stays visible (z-index 2^31) */
      `,document.head.appendChild(e)}function Pe(){var e;(e=document.getElementById("moodscroll-sidekick-css"))==null||e.remove()}let _=null,c=null;function le(){_&&document.documentElement.contains(_)||(document.querySelectorAll("#moodscroll-overlay-root").forEach(e=>e.remove()),_=document.createElement("div"),_.id="moodscroll-overlay-root",_.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;",c=_.attachShadow({mode:"open"}),c.innerHTML=He(),document.documentElement.appendChild(_),Fe(),L(),ue())}function He(){return`
<style>
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', system-ui, sans-serif;
    --bg-base: rgba(22, 22, 24, 0.78);
    --bg-elevated: rgba(255, 255, 255, 0.05);
    --bg-elevated-hover: rgba(255, 255, 255, 0.09);
    --border-subtle: rgba(255, 255, 255, 0.08);
    --border-strong: rgba(255, 255, 255, 0.16);
    --text-primary: rgba(255, 255, 255, 0.95);
    --text-secondary: rgba(255, 255, 255, 0.58);
    --text-tertiary: rgba(255, 255, 255, 0.36);
    --accent: #ffd75a;
    --accent-rich: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    --success: #34d399;
    --success-rich: linear-gradient(180deg, #4ade80 0%, #22c55e 100%);
    --danger: #f87171;
    --danger-rich: linear-gradient(180deg, #fb7185 0%, #e11d48 100%);
    --purple: #a78bfa;
    --purple-rich: linear-gradient(180deg, #c4b5fd 0%, #8b5cf6 100%);
    --spring: cubic-bezier(0.32, 1.45, 0.6, 1);
    --ease: cubic-bezier(0.4, 0, 0.2, 1);
  }
  * { box-sizing: border-box; font-family: inherit; -webkit-font-smoothing: antialiased; }

  /* ---------- FLOATING TOGGLE ---------- */
  .ms-toggle {
    position: fixed; bottom: 80px; right: 20px; width: 52px; height: 52px;
    border-radius: 50%;
    background: linear-gradient(180deg, rgba(50,50,55,0.85), rgba(22,22,24,0.85));
    color: var(--text-primary);
    border: 0.5px solid rgba(255,255,255,0.18);
    cursor: pointer; font-size: 22px; line-height: 1;
    box-shadow:
      inset 0 1px 0 rgba(255,255,255,0.12),
      inset 0 -1px 0 rgba(0,0,0,0.3),
      0 8px 24px rgba(0,0,0,0.5),
      0 1px 2px rgba(0,0,0,0.3);
    transition: transform 0.25s var(--spring), box-shadow 0.25s var(--ease), background 0.25s var(--ease);
    display: flex; align-items: center; justify-content: center;
    pointer-events: auto;
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
  }
  .ms-toggle:hover { transform: translateY(-2px) scale(1.05); box-shadow: inset 0 1px 0 rgba(255,255,255,0.15), inset 0 -1px 0 rgba(0,0,0,0.3), 0 12px 32px rgba(0,0,0,0.6); }
  .ms-toggle:active { transform: scale(0.95); }
  .ms-toggle.active {
    background: var(--accent-rich);
    color: #1a1500; border-color: rgba(255, 217, 90, 0.5);
    box-shadow:
      0 0 0 4px rgba(255, 217, 90, 0.12),
      0 8px 32px rgba(255, 217, 90, 0.35),
      inset 0 1px 0 rgba(255,255,255,0.4);
  }
  .ms-toggle .ms-pulse {
    position: absolute; inset: -8px; border-radius: 50%;
    border: 1.5px solid var(--accent); opacity: 0; pointer-events: none;
    animation: msPulse 2.4s var(--ease) infinite;
  }
  .ms-toggle.active .ms-pulse { opacity: 1; }
  @keyframes msPulse {
    0% { transform: scale(0.85); opacity: 0.9; }
    100% { transform: scale(1.6); opacity: 0; }
  }

  /* ---------- DECISION FLASH ---------- */
  .ms-flash {
    position: fixed; bottom: 148px; right: 20px;
    padding: 9px 16px; border-radius: 100px;
    font-size: 11.5px; font-weight: 600; letter-spacing: -0.01em;
    pointer-events: none; opacity: 0;
    transform: translateY(8px);
    transition: all 0.4s var(--spring);
    backdrop-filter: blur(20px) saturate(180%);
    box-shadow: 0 8px 24px rgba(0,0,0,0.35);
    border: 0.5px solid rgba(255,255,255,0.15);
  }
  .ms-flash.show { opacity: 1; transform: translateY(0); }
  .ms-flash.match { background: var(--success-rich); color: #042818; }
  .ms-flash.skip { background: var(--danger-rich); color: #ffffff; }

  /* ---------- LOCKED-IN CELEBRATION BANNER ---------- */
  .ms-locked-banner {
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.85);
    background: linear-gradient(180deg, rgba(20, 50, 32, 0.95), rgba(15, 35, 22, 0.95));
    color: #4ade80;
    border: 1px solid rgba(74, 222, 128, 0.4);
    border-radius: 20px; padding: 28px 40px;
    box-shadow: 0 0 0 4px rgba(74, 222, 128, 0.12), 0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.08);
    backdrop-filter: blur(28px) saturate(180%);
    -webkit-backdrop-filter: blur(28px) saturate(180%);
    pointer-events: none; opacity: 0;
    z-index: 2147483647;
    transition: opacity 0.5s var(--ease), transform 0.6s var(--spring);
    text-align: center; min-width: 320px;
  }
  .ms-locked-banner.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  .ms-locked-icon { font-size: 56px; line-height: 1; margin-bottom: 10px; }
  .ms-locked-title { font-size: 22px; font-weight: 700; letter-spacing: -0.02em;
    background: linear-gradient(180deg, #fff, #4ade80); -webkit-background-clip: text;
    -webkit-text-fill-color: transparent; margin-bottom: 6px; }
  .ms-locked-sub { font-size: 13px; color: rgba(255,255,255,0.65); letter-spacing: -0.005em; }
  .ms-locked-cta {
    pointer-events: auto; cursor: pointer;
    display: block; margin-left: auto; margin-right: auto;
    margin-top: 16px; padding: 10px 18px;
    border: none; border-radius: 10px;
    background: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    color: #1a1500; font-weight: 700; font-size: 13px; letter-spacing: -0.01em;
    font-family: inherit;
    box-shadow: 0 2px 10px rgba(255,217,90,0.3);
    transition: transform 0.15s ease, box-shadow 0.15s ease;
  }
  .ms-locked-cta:hover { transform: translateY(-1px); box-shadow: 0 4px 14px rgba(255,217,90,0.45); }
  .ms-locked-cta-ghost {
    margin-top: 8px; padding: 8px 16px;
    background: transparent; color: rgba(255,255,255,0.78);
    border: 1px solid rgba(255,255,255,0.22); box-shadow: none; font-weight: 600;
  }
  .ms-locked-cta-ghost:hover { transform: translateY(-1px); box-shadow: none;
    background: rgba(255,255,255,0.06); color: #fff; }

  /* ---------- PANEL ---------- */
  .ms-panel {
    position: fixed; bottom: 148px; right: 20px; width: 304px;
    background: var(--bg-base);
    color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 18px; padding: 16px 14px 14px;
    box-shadow:
      0 0 0 0.5px rgba(0,0,0,0.5),
      0 40px 100px -10px rgba(0,0,0,0.75),
      inset 0 0.5px 0 rgba(255,255,255,0.07);
    backdrop-filter: blur(48px) saturate(200%);
    -webkit-backdrop-filter: blur(48px) saturate(200%);
    display: none; pointer-events: auto;
    transform-origin: bottom right;
    opacity: 0; transform: translateY(8px) scale(0.96);
    transition: opacity 0.28s var(--ease), transform 0.32s var(--spring);
  }
  .ms-panel.open { display: block; opacity: 1; transform: translateY(0) scale(1); }

  .ms-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 2px;
  }
  .ms-title {
    font-size: 15px; font-weight: 600; letter-spacing: -0.02em;
    color: var(--text-primary);
  }
  .ms-close {
    background: rgba(255,255,255,0.06);
    color: var(--text-tertiary); border: none; cursor: pointer;
    font-size: 13px; line-height: 1; padding: 0;
    width: 22px; height: 22px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.18s var(--ease);
  }
  .ms-close:hover { background: rgba(255,255,255,0.14); color: var(--text-primary); }
  .ms-subtitle {
    font-size: 11px; color: var(--text-tertiary);
    margin-bottom: 12px; letter-spacing: -0.005em;
  }

  /* ---------- MODE GRID ---------- */
  .ms-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin-bottom: 10px;
  }
  .ms-mode {
    background: rgba(255,255,255,0.04);
    color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 9px; padding: 9px 9px;
    cursor: pointer;
    display: flex; align-items: center; gap: 7px;
    font-size: 11.5px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease), transform 0.16s var(--spring);
  }
  .ms-mode:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-mode:active { transform: scale(0.97); }
  .ms-mode.active {
    background: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    color: #1a1500;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.4);
    font-weight: 600;
  }
  .ms-emoji { font-size: 15px; line-height: 1; flex-shrink: 0; }
  .ms-label { font-size: 11.5px; }

  /* ---------- CUSTOM INPUT ---------- */
  .ms-custom-wrap { margin-bottom: 12px; display: none; }
  .ms-custom-wrap.show { display: block; animation: msSlideDown 0.32s var(--spring); }
  @keyframes msSlideDown { from { opacity: 0; transform: translateY(-6px); max-height: 0; } to { opacity: 1; transform: translateY(0); max-height: 80px; } }
  .ms-custom-input {
    width: 100%; padding: 11px 13px;
    background: rgba(255,255,255,0.05); color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 10px; font-size: 13px;
    font-family: inherit; letter-spacing: -0.01em;
    box-sizing: border-box;
    transition: all 0.2s var(--ease);
  }
  .ms-custom-input::placeholder { color: var(--text-tertiary); }
  .ms-custom-input:focus {
    outline: none; border-color: var(--accent);
    background: rgba(255,255,255,0.08);
    box-shadow: 0 0 0 3px rgba(255, 217, 90, 0.1);
  }
  .ms-custom-hint {
    font-size: 10.5px; color: var(--text-tertiary);
    margin-top: 6px; padding-left: 2px; letter-spacing: -0.005em;
  }

  /* ---------- ACTIVE LINE ---------- */
  .ms-active-line {
    font-size: 11px; padding: 8px 11px;
    background: rgba(52,211,153,0.07); color: var(--success);
    border: 0.5px solid rgba(52,211,153,0.18);
    border-radius: 9px; margin-bottom: 10px;
    letter-spacing: -0.005em; display: none;
  }
  .ms-active-line.show { display: block; }
  .ms-active-line b { color: white; font-weight: 600; }

  /* ---------- PHASE INDICATOR ---------- */
  .ms-phase {
    background: rgba(255,255,255,0.04);
    border: 0.5px solid var(--border-subtle);
    border-radius: 12px; padding: 10px 12px; margin-bottom: 12px;
    display: none;
  }
  .ms-phase.show { display: block; }
  .ms-phase-row {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 11.5px; margin-bottom: 7px; letter-spacing: -0.01em;
  }
  .ms-phase-label {
    color: var(--text-primary); font-weight: 500;
    display: flex; align-items: center; gap: 6px;
  }
  .ms-phase-label::before {
    content: ''; width: 6px; height: 6px; border-radius: 50%;
    background: var(--accent); box-shadow: 0 0 8px var(--accent);
    animation: msBlink 1.4s ease-in-out infinite;
  }
  .ms-phase.stable .ms-phase-label::before {
    background: var(--success); box-shadow: 0 0 8px var(--success); animation: none;
  }
  @keyframes msBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  .ms-phase-stat { color: var(--text-tertiary); font-variant-numeric: tabular-nums; font-size: 11px; }
  .ms-phase-bar {
    height: 4px; background: rgba(255,255,255,0.08); border-radius: 100px; overflow: hidden;
  }
  .ms-phase-fill {
    height: 100%; width: 0%;
    background: linear-gradient(90deg, var(--accent), var(--success));
    border-radius: 100px;
    transition: width 0.6s var(--ease);
  }
  .ms-phase.stable .ms-phase-fill { background: var(--success); }

  /* ---------- STATS — minimal inline strip ---------- */
  .ms-stats {
    display: flex; justify-content: space-between;
    padding: 7px 4px;
    margin-bottom: 10px;
    font-size: 10.5px; color: var(--text-tertiary);
    letter-spacing: 0;
    border-top: 0.5px solid var(--border-subtle);
    border-bottom: 0.5px solid var(--border-subtle);
  }
  .ms-stat-cell {
    display: flex; align-items: baseline; gap: 4px;
  }
  .ms-stat-cell b {
    color: var(--text-primary); font-weight: 600; font-size: 12px;
    font-variant-numeric: tabular-nums; letter-spacing: -0.015em;
  }
  .ms-stat-cell span { font-size: 10.5px; color: var(--text-tertiary); }

  /* ---------- ENGAGE TOGGLE ROW ---------- */
  .ms-toggle-row {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 11px; padding: 3px 2px; margin-bottom: 10px;
    color: var(--text-secondary); letter-spacing: -0.005em;
  }
  .ms-switch { position: relative; display: inline-block; width: 30px; height: 18px; }
  .ms-switch input { opacity: 0; width: 0; height: 0; }
  .ms-slider {
    position: absolute; cursor: pointer; inset: 0;
    background: rgba(255,255,255,0.12);
    border-radius: 18px; transition: background 0.22s var(--ease);
  }
  .ms-slider::before {
    position: absolute; content: ""; height: 14px; width: 14px;
    left: 2px; top: 2px; background: white;
    border-radius: 50%; transition: transform 0.26s var(--spring);
    box-shadow: 0 1px 3px rgba(0,0,0,0.35);
  }
  input:checked + .ms-slider { background: var(--success); }
  input:checked + .ms-slider::before { transform: translateX(12px); }

  /* ---------- LAYOUT BUTTONS ---------- */
  .ms-sidekick-row { display: grid; grid-template-columns: 1.6fr 1fr; gap: 5px; margin-bottom: 6px; }
  .ms-sidekick-btn {
    padding: 9px 6px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  /* The primary Phone Mode button — slightly bigger, accent-colored */
  .ms-phone-btn {
    background: rgba(255, 217, 90, 0.08) !important;
    color: var(--accent) !important;
    border-color: rgba(255, 217, 90, 0.22) !important;
    font-weight: 600 !important;
  }
  .ms-phone-btn:hover {
    background: rgba(255, 217, 90, 0.14) !important;
    border-color: rgba(255, 217, 90, 0.4) !important;
  }
  .ms-phone-btn.active {
    background: linear-gradient(180deg, #ffe07a, #ffc83d) !important;
    color: #1a1500 !important;
    border-color: transparent !important;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.35);
  }
  .ms-sidekick-btn:hover {
    background: rgba(167, 139, 250, 0.09); color: var(--purple);
    border-color: rgba(167, 139, 250, 0.25);
  }
  .ms-sidekick-btn.active:not(.ms-phone-btn) {
    background: linear-gradient(180deg, #c4b5fd, #8b5cf6); color: white;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(167, 139, 250, 0.28), inset 0 1px 0 rgba(255,255,255,0.22);
  }

  /* ---------- ACTIONS ---------- */
  .ms-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin-bottom: 5px; }
  .ms-stop, .ms-receipt-btn {
    padding: 8px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  .ms-receipt-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-stop:hover {
    background: rgba(248,113,113,0.09); color: var(--danger);
    border-color: rgba(248,113,113,0.25);
  }
  .ms-reset-btn {
    width: 100%; padding: 8px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  .ms-reset-btn:hover {
    background: rgba(255,217,90,0.08); color: var(--accent);
    border-color: rgba(255,217,90,0.25);
  }
</style>
<button class="ms-toggle" id="ms-toggle" title="Mood Scroll — click to open"><span class="ms-pulse"></span><span id="ms-toggle-icon">✨</span></button>
<div class="ms-flash" id="ms-flash"></div>
<div class="ms-locked-banner" id="ms-locked-banner">
  <div class="ms-locked-icon">🎯</div>
  <div class="ms-locked-title">LOCKED IN</div>
  <div class="ms-locked-sub">Algorithm tuned · scrolling at natural pace</div>
</div>
<div class="ms-panel" id="ms-panel">
  <div class="ms-header">
    <span class="ms-title">Mood Scroll</span>
    <button class="ms-close" id="ms-close">×</button>
  </div>
  <div class="ms-subtitle">pick a mood — i'll filter the feed</div>
  <div class="ms-grid">${M.map(t=>`<button class="ms-mode" data-mode="${t.id}"><span class="ms-emoji">${t.emoji}</span><span class="ms-label">${t.label}</span></button>`).join("")}</div>
  <div class="ms-custom-wrap" id="ms-custom-wrap">
    <input class="ms-custom-input" id="ms-custom-input" type="text" placeholder="describe what you want..." maxlength="200" />
    <div class="ms-custom-hint">enter to activate · examples: "startup founders", "60s rock", "golden retrievers"</div>
  </div>
  <div class="ms-active-line" id="ms-active-line">Active: <b id="ms-active-text"></b></div>
  <div class="ms-phase" id="ms-phase">
    <div class="ms-phase-row">
      <span class="ms-phase-label" id="ms-phase-label">Training the algo</span>
      <span class="ms-phase-stat" id="ms-phase-stat">0/0 matched</span>
    </div>
    <div class="ms-phase-bar"><div class="ms-phase-fill" id="ms-phase-fill"></div></div>
  </div>
  <div class="ms-stats">
    <div class="ms-stat-cell"><b id="ms-timer">0:00</b></div>
    <div class="ms-stat-cell"><b id="ms-watched">0</b><span>watched</span></div>
    <div class="ms-stat-cell"><b id="ms-skipped">0</b><span>skipped</span></div>
  </div>
  <div class="ms-toggle-row">
    <span>train algo (auto-like matches)</span>
    <label class="ms-switch">
      <input type="checkbox" id="ms-engage-toggle" />
      <span class="ms-slider"></span>
    </label>
  </div>
  <div class="ms-sidekick-row">
    <button class="ms-sidekick-btn ms-phone-btn" id="ms-sidekick-btn" title="One click: shrink Chrome to a phone-sized strip on the right edge of your screen, hide all of TikTok's nav/buttons/captions so only the video shows, and auto-start scrolling. Work on the rest of your screen while TikTok plays.">📱 Phone Mode</button>
    <button class="ms-sidekick-btn" id="ms-popout-btn" title="Open TikTok in a NEW narrow window instead of resizing this one. Use if you want your current tabs to stay full-size.">🪟 New Window</button>
  </div>
  <div class="ms-actions">
    <button class="ms-receipt-btn" id="ms-receipt-btn">📊 Receipt</button>
    <button class="ms-stop" id="ms-stop">⏹ Stop</button>
  </div>
  <button class="ms-reset-btn" id="ms-reset-btn" title="Reset everything: opens TikTok content preferences in a new tab (where you can 'Refresh your For You feed') and clears Mood Scroll's training history so the next mode locks in faster.">🔄 Reset algo</button>
</div>
      `}function Fe(){if(!c)return;const e=c.getElementById("ms-toggle"),t=c.getElementById("ms-panel"),n=c.getElementById("ms-close"),r=c.getElementById("ms-custom-wrap"),s=c.getElementById("ms-custom-input"),a=c.getElementById("ms-engage-toggle"),d=c.getElementById("ms-stop"),u=c.getElementById("ms-receipt-btn");e.addEventListener("click",()=>{t.classList.toggle("open")}),n.addEventListener("click",()=>t.classList.remove("open")),c.querySelectorAll(".ms-mode").forEach(p=>{p.addEventListener("click",()=>{const w=p.dataset.mode;w==="custom"?(r.classList.add("show"),s.value=l,s.focus(),l?te("custom"):L()):(r.classList.remove("show"),te(w))})}),s.addEventListener("keydown",p=>{if(p.key==="Enter"){const w=s.value.trim();if(!w)return;l=w,chrome.storage.local.set({customDescription:w}),te("custom")}}),s.addEventListener("blur",()=>{const p=s.value.trim();p&&p!==l&&(l=p,chrome.storage.local.set({customDescription:p}),o==="custom"&&L())}),a.checked=m,a.addEventListener("change",()=>{m=a.checked,chrome.storage.local.set({autoEngage:m})}),d.addEventListener("click",()=>{o=null,chrome.storage.local.set({currentMode:null}),L()}),u.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open_receipt"}).catch(()=>{})});const h=c.getElementById("ms-reset-btn");h||console.warn("[MoodScroll] Reset button NOT FOUND — old content script still running? Close + reopen the TikTok tab."),h&&(console.log("[MoodScroll] Reset button wired up ✓"),h.addEventListener("click",async p=>{p.stopPropagation(),p.preventDefault(),console.log("[MoodScroll] 🔄 Reset Algo clicked");const w=o;o=null,y.length=0,v="training",T=0,B=0,I=null,F.clear(),x.length=0,await chrome.storage.local.set({currentMode:null,justReset:!0}).catch(()=>{});const Y=await chrome.runtime.sendMessage({type:"reset_session"}).catch(C=>({error:String(C)}));console.log("[MoodScroll] session cleared:",Y),de(),ue(),L(),j(!0,"🔄 RESET"),We();const z=await chrome.runtime.sendMessage({type:"open_tiktok_settings"}).catch(C=>({error:String(C)}));console.log("[MoodScroll] TikTok settings tab opened:",z,"(was mode:",w,")"),setTimeout(()=>{console.log("[MoodScroll] 🔁 Reloading TikTok tab to /foryou for clean state…"),window.location.href="https://www.tiktok.com/foryou"},2200)}));const S=c.getElementById("ms-sidekick-btn");S&&S.addEventListener("click",async()=>{const p=window.screen.availWidth,w=window.screen.availHeight;k?(await chrome.runtime.sendMessage({type:"sidekick_off",screenW:p,screenH:w}).catch(()=>{}),k=!1,Pe(),chrome.storage.local.set({sidekickActive:!1})):(await chrome.runtime.sendMessage({type:"sidekick_on",screenW:p,screenH:w}).catch(()=>{}),k=!0,ye(),chrome.storage.local.set({sidekickActive:!0}),o||te("auto_scroll"),t.classList.remove("open")),L()});const D=c.getElementById("ms-popout-btn");D&&D.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"pop_out_side",screenW:window.screen.availWidth,screenH:window.screen.availHeight}).catch(()=>{}),t.classList.remove("open")})}function te(e){o=e,chrome.storage.local.set({currentMode:e}),I=null,me(),L()}function L(){if(!c)return;const e=c.getElementById("ms-toggle"),t=c.getElementById("ms-toggle-icon"),n=c.getElementById("ms-active-line"),r=c.getElementById("ms-active-text"),s=c.getElementById("ms-custom-wrap"),a=c.getElementById("ms-sidekick-btn");if(!(!e||!t||!n||!r||!s)){if(c.querySelectorAll(".ms-mode").forEach(d=>{const u=d.dataset.mode;d.classList.toggle("active",u===o)}),o){const d=M.find(u=>u.id===o);e.classList.add("active"),t.textContent=(d==null?void 0:d.emoji)||"✨",n.classList.add("show"),o==="custom"?(r.textContent=`Custom — "${l||"(empty)"}"`,s.classList.add("show")):o==="auto_scroll"?r.textContent="Auto Scroll · every 5s":r.textContent=(d==null?void 0:d.label)||o}else e.classList.remove("active"),t.textContent="✨",n.classList.remove("show");a&&(a.classList.toggle("active",k),a.textContent=k?"✕ Exit Phone Mode":"📱 Phone Mode")}}function j(e,t){if(!c)return;const n=c.getElementById("ms-flash");n&&(o==="auto_scroll"?(n.textContent=`⏩ ${t}`,n.className="ms-flash show match"):(n.textContent=e?`MATCH · ${t}`:`SKIP · ${t}`,n.className="ms-flash show "+(e?"match":"skip")),setTimeout(()=>n.classList.remove("show"),1800))}function ke(e){y.push(e),y.length>W&&y.shift();const t=y.filter(Boolean).length,n=y.length?t/y.length:0;let r=v;if(v==="training"&&y.length>=5&&n>=_e?r="stable":v==="stable"&&n<Re&&(r="training"),r!==v){const s=v;v=r,console.log("[MoodScroll] phase →",v,`(${t}/${y.length})`),s==="training"&&r==="stable"&&je()}de()}function je(){var r;if(!c)return;const e=c.getElementById("ms-locked-banner");if(!e)return;const t=M.find(s=>s.id===o),n=o==="custom"?`"${l||"Custom"}"`:((t==null?void 0:t.label)||o||"").toUpperCase();e.querySelector(".ms-locked-icon").textContent="🎯",e.querySelector(".ms-locked-sub").textContent="Algorithm tuned · scrolling at natural pace",e.querySelector(".ms-locked-title").textContent=`${n} LOCKED IN`,(r=e.querySelector(".ms-locked-cta"))==null||r.remove(),e.classList.add("show"),setTimeout(()=>e.classList.remove("show"),4e3)}function Ge(){var d;if(!c)return;const e=c.getElementById("ms-locked-banner");if(!e)return;const t=e.querySelector(".ms-locked-title"),n=e.querySelector(".ms-locked-sub"),r=e.querySelector(".ms-locked-icon");r.textContent="🎉",t.textContent="FREE LIMIT REACHED",n.innerHTML="The first 100 free spots are taken. Get lifetime access for $10 and add your own OpenAI key — then keep scrolling your way.",(d=e.querySelector(".ms-locked-cta"))==null||d.remove();const s=document.createElement("button");s.className="ms-locked-cta",s.textContent="Get $10 lifetime →",s.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open_site",path:"/#pricing"}).catch(()=>{})}),e.appendChild(s);const a=document.createElement("button");a.className="ms-locked-cta ms-locked-cta-ghost",a.textContent="Paste your key in Options",a.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open_options"}).catch(()=>{})}),e.appendChild(a),e.classList.add("show"),setTimeout(()=>e.classList.remove("show"),16e3)}function Ve(){var s;if(!c)return;const e=c.getElementById("ms-locked-banner");if(!e)return;const t=e.querySelector(".ms-locked-title"),n=e.querySelector(".ms-locked-sub"),r=e.querySelector(".ms-locked-icon");r.textContent="⏳",t.textContent="TAKING A BREAK",n.textContent="The AI is busy for a moment. Hang tight — it’ll pick back up automatically.",(s=e.querySelector(".ms-locked-cta"))==null||s.remove(),e.classList.add("show"),setTimeout(()=>e.classList.remove("show"),9e3)}function We(){var u;if(!c)return;const e=c.getElementById("ms-locked-banner");if(!e)return;const t=e.querySelector(".ms-locked-title"),n=e.querySelector(".ms-locked-sub"),r=e.querySelector(".ms-locked-icon"),s=t.textContent,a=n.textContent,d=r.textContent;r.textContent="🔄",t.textContent="RESET COMPLETE",n.textContent='Refreshing feed… click "Refresh your For You feed" in the new tab too',(u=e.querySelector(".ms-locked-cta"))==null||u.remove(),e.classList.add("show"),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>{r.textContent=d||"🎯",t.textContent=s||"LOCKED IN",n.textContent=a||"Algorithm tuned · scrolling at natural pace"},600)},4500)}function de(){if(!c)return;const e=c.getElementById("ms-phase"),t=c.getElementById("ms-phase-label"),n=c.getElementById("ms-phase-stat"),r=c.getElementById("ms-phase-fill");if(!e||!t||!n||!r)return;if(!o||o==="auto_scroll"){e.classList.remove("show");return}e.classList.add("show");const s=y.filter(Boolean).length,a=y.length?Math.round(s/y.length*100):0;v==="training"?(e.classList.remove("stable"),t.textContent="Training (broad cluster)",n.textContent=`${s}/${y.length||0} matched`):(e.classList.add("stable"),t.textContent=`Tuned · strict ${a}%`,n.textContent="auto pace"),r.style.width=`${a}%`}function me(){v="training",y.length=0,de()}async function ue(){if(c)try{const{session:e}=await chrome.storage.local.get("session"),t=(e==null?void 0:e.watched)||0,n=(e==null?void 0:e.skipped)||0,r=(e==null?void 0:e.startedAt)||Date.now(),s=Math.floor((Date.now()-r)/1e3),a=Math.floor(s/60),d=s%60,u=c.getElementById("ms-watched"),h=c.getElementById("ms-skipped"),S=c.getElementById("ms-timer");u&&(u.textContent=String(t)),h&&(h.textContent=String(n)),S&&(S.textContent=`${a}:${String(d).padStart(2,"0")}`)}catch{}}let pe=null;const Ue=new MutationObserver(()=>{pe||(pe=window.setTimeout(()=>{pe=null,(!_||!document.documentElement.contains(_))&&le()},250))});document.documentElement&&(le(),Ue.observe(document.documentElement,{childList:!0})),document.addEventListener("DOMContentLoaded",()=>le(),{once:!0}),setInterval(ue,1e3),chrome.storage.local.get(["justReset"]).then(({justReset:e})=>{if(!e)return;chrome.storage.local.remove("justReset");const t=()=>{var d;if(!c){setTimeout(t,200);return}const n=c.getElementById("ms-locked-banner");if(!n){setTimeout(t,200);return}const r=n.querySelector(".ms-locked-title"),s=n.querySelector(".ms-locked-sub"),a=n.querySelector(".ms-locked-icon");a.textContent="✅",r.textContent="RESET DONE",s.textContent="Pick a mode to start training a fresh algorithm",(d=n.querySelector(".ms-locked-cta"))==null||d.remove(),n.classList.add("show"),setTimeout(()=>n.classList.remove("show"),4e3)};t()}),setInterval(()=>{if(!o||o==="auto_scroll"||T===0||Date.now()<T)return;const e=R();if(!e){T=0,B=0;return}T=0,B=0,q(e.currentSrc)},250);let oe=!1,U=null;setInterval(async()=>{var n,r,s,a;if(o!=="auto_scroll"){U=null;return}if(oe)return;const e=R();if(!e)return;const t=e.currentSrc;if(U!==t){U=t,oe=!0;try{const d=e.closest(i.itemSelector),u=d||document,h=((r=(n=u.querySelector(i.captionSelector))==null?void 0:n.textContent)==null?void 0:r.trim())||"";if(we(d,h)){j(!1,"sponsored ad"),chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),q(t),oe=!1,U=null;return}const S=Array.from(h.matchAll(/#([\w]+)/g)).map(f=>f[1]),D=((a=(s=u.querySelector(i.audioSelector))==null?void 0:s.textContent)==null?void 0:a.trim())||"",p=u.querySelector(i.creatorSelector),w=((p==null?void 0:p.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown",Y=await ge(e),z=await chrome.runtime.sendMessage({type:"classify",frames:Y?[Y]:[],caption:h,hashtags:S,sound:D,creator:w,mode:"other"}).catch(()=>null),C=(z==null?void 0:z.category)||"other",G=be(C,e);T=Date.now()+G,j(!0,`${C} · ${Math.round(G/1e3)}s`),chrome.runtime.sendMessage({type:"tally",category:C,matched:!0}).catch(()=>{}),m&&Ee(t,!0),console.log(`[MoodScroll] auto-scroll: ${C}, holding ${G}ms`)}catch{T=Date.now()+5e3}finally{oe=!1}return}Date.now()>=T&&(q(t),U=null)},500),setInterval(async()=>{var e,t,n,r;try{if(!o||b||o==="auto_scroll"||o==="custom"&&!l||Date.now()-A<ce().decisionIntervalMs)return;const s=R();if(!s||s.currentSrc===I)return;b=!0;const a=s.currentSrc,d=o,u=s.closest(i.itemSelector),h=u||document,S=((t=(e=h.querySelector(i.captionSelector))==null?void 0:e.textContent)==null?void 0:t.trim())||"",D=Array.from(S.matchAll(/#([\w]+)/g)).map(g=>g[1]),p=((r=(n=h.querySelector(i.audioSelector))==null?void 0:n.textContent)==null?void 0:r.trim())||"",w=h.querySelector(i.creatorSelector),z=((w==null?void 0:w.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown";if(o!=="custom"&&!S&&z==="unknown"){b=!1;return}if(we(u,S)){chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),I=a,A=Date.now(),b=!1,j(!1,"📣 sponsored ad"),console.log("[MoodScroll] SKIP sponsored ad"),q(a);return}const C=ee.has(o||"")?[]:$e[o||""]||[],G=D.map(g=>g.toLowerCase());if(C.length&&C.some(g=>G.includes(g.toLowerCase()))){const g=C.find(E=>G.includes(E.toLowerCase()));chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),I=a,A=Date.now(),b=!1,j(!1,`pre-skip #${g}`),ke(!1),console.log("[MoodScroll] INSTANT SKIP via negative hashtag",`#${g}`,"for",o),q(a);return}let f=null;if(o!=="custom"&&!ee.has(o||"")){const g=Ce(S,D,p);if(g.confidence>=.8&&g.category){const E=M.find(ne=>ne.id===o),O=(E==null?void 0:E.matches)??[];O.includes(g.category)||(f={category:g.category,confidence:g.confidence},console.log(`[MoodScroll] Tier1 confident SKIP: ${g.category} ∉ [${O.join(",")}]`))}}if(!f){const g=ce().useFrames||o==="custom"||ee.has(o||"");let E=[];if(g){if(E=await Ke(s),E.length===0){const K=await ge(s);K&&(E=[K])}}else{const K=await ge(s);K&&(E=[K])}const O=await chrome.runtime.sendMessage({type:"classify",frames:E,caption:S,hashtags:D,sound:p,creator:z,mode:o,customDescription:o==="custom"?l:void 0}),ne=R();if(!ne||ne.currentSrc!==a){b=!1;return}if(O!=null&&O.error){console.warn("[MoodScroll] classify error:",O.error),O.error==="free_limit_reached"?(Ge(),o=null,chrome.storage.local.set({currentMode:null}).catch(()=>{}),L()):Ve(),b=!1;return}f=O;const Ie=new Set(["larp","baddies","brain_rot"]).has(o||"")?.3:ee.has(o||"")?.4:.6;f&&typeof f.confidence=="number"&&f.confidence<Ie&&(console.log(`[MoodScroll] Low confidence (${f.confidence} < ${Ie}) → demoting to 'other'`),f={...f,category:"other"})}if(!f){b=!1;return}const N=M.find(g=>g.id===o),Je=v==="stable"?(N==null?void 0:N.matches)??[]:(N==null?void 0:N.broadMatches)??(N==null?void 0:N.matches)??[],se=o==="custom"?typeof f.matches_mode=="boolean"?f.matches_mode:!1:Je.includes(f.category);chrome.runtime.sendMessage({type:"tally",category:f.category,matched:se}).catch(()=>{}),I=a,A=Date.now(),b=!1;const Me=R();if(!Me||Me.currentSrc!==a){console.log("[MoodScroll] video advanced before decision applied, dropping");return}if(j(se,f.category),ke(se),!se)console.log("[MoodScroll] SKIP:",f.category,"|",f.reason||""),q(a);else{const g=R(),E=be(f.category,g);T=Date.now()+E,B=0,console.log(`[MoodScroll] MATCH: ${f.category}, holding ${E}ms (dur=${g==null?void 0:g.duration}s) | ${f.reason||""}`),m&&Ee(a,!0)}}catch(s){console.error("[MoodScroll] loop error:",s),b=!1}},i.tickIntervalMs);function R(){const e=document.querySelectorAll(i.videoSelector);if(!e.length)return null;const t=window.innerHeight/2;let n=null,r=1/0;for(const s of e){const a=s.getBoundingClientRect();if(a.height<i.minVideoHeight||a.bottom<0||a.top>window.innerHeight||!s.currentSrc)continue;const d=(a.top+a.bottom)/2,u=Math.abs(d-t);u<r&&(r=u,n=s)}return n}function ve(){return Array.from(document.querySelectorAll(i.itemSelector))}function Ye(e){for(const t of ve()){const n=t.querySelector("video");if(n&&n.currentSrc===e)return t}return null}function we(e,t){if(!e)return!1;const n=['[data-e2e="ad-info"]','[data-e2e="video-ad"]','[data-e2e="ad-card"]','[data-e2e="ad-overlay"]','[data-e2e="ad-tag"]','[data-e2e="branded-content-tag"]','[data-e2e="paid-partnership-tag"]'];for(const d of n)if(e.querySelector(d))return!0;const r=e.textContent||"";if(/(^|\s)(Sponsored|Promoted|Advertisement|Paid partnership)(\s|$|\.|,)/i.test(r)||/#(ad|sponsored|spon|paidpromotion|paidpartnership|partnership|brandpartner|sponsoredpost|brandeddeal|advertorial)\b/i.test(t))return!0;const a=['button[data-e2e*="ad-button" i]','a[data-e2e*="ad-link" i]','a[href*="utm_source=tiktok"]'];for(const d of a)if(e.querySelector(d))return!0;return!1}function xe(e){if(e.readyState<2)return null;try{const t=document.createElement("canvas");t.width=480,t.height=854;const n=t.getContext("2d");return n?(n.drawImage(e,0,0,t.width,t.height),t.toDataURL("image/jpeg",.75)):null}catch{return null}}async function ge(e){let t=xe(e);if(t)return t;try{await e.play().catch(()=>{})}catch{}for(let n=0;n<5;n++)if(await new Promise(r=>setTimeout(r,200)),t=xe(e),t)return t;return null}async function Ke(e){const t=[],n=[400,500,500],r=e.currentSrc;for(const s of n){if(s>0&&await new Promise(a=>setTimeout(a,s)),e.paused||e.readyState<2||e.currentSrc!==r)break;try{const a=document.createElement("canvas");a.width=480,a.height=854;const d=a.getContext("2d");if(!d)continue;d.drawImage(e,0,0,a.width,a.height),t.push(a.toDataURL("image/jpeg",.75))}catch(a){console.warn("[MoodScroll] frame capture failed:",a)}}return t}function q(e){Se(e),setTimeout(()=>{const t=R();t&&t.currentSrc===e&&Se(e)},400)}function Se(e){const t=ve(),n=Ye(e)||t.find(s=>{const a=s.getBoundingClientRect();return a.top<window.innerHeight/2&&a.bottom>window.innerHeight/2});if(n&&t.length){const s=t.indexOf(n),a=s>=0?t[s+1]:null;if(a){a.scrollIntoView({behavior:"smooth",block:"center"});return}}const r=document.getElementById(i.scrollContainerId);if(r){r.scrollBy({top:r.clientHeight,behavior:"smooth"});return}window.scrollBy({top:window.innerHeight,behavior:"smooth"})}function Ee(e,t=!1){if(F.has(e)||!t&&Math.random()>ce().likeProbability)return;const n=Date.now();for(;x.length&&n-x[0]>i.likeRateLimitWindowMs;)x.shift();if(x.length>=i.likeRateLimitMax){console.log("[MoodScroll] like rate-limit reached, skipping");return}const r=t?800+Math.random()*600:i.likeDelayMinMs+Math.random()*i.likeDelayJitterMs;setTimeout(()=>{const s=R();if(!s||s.currentSrc!==e)return;const d=s.closest(i.itemSelector)||document,u=d.querySelector(i.likeIconSelector),h=(u==null?void 0:u.closest("button"))||d.querySelector(i.likeAriaSelector);if(((h==null?void 0:h.getAttribute("aria-label"))||"").toLowerCase().startsWith("unlike")||(h==null?void 0:h.getAttribute("aria-pressed"))==="true"){F.add(e);return}const D=Xe(s);let p=!1;h&&(h.click(),p=!0),F.add(e),x.push(Date.now()),console.log(`[MoodScroll] ❤️ liked match (dblclick=${D}, btn=${p})`)},r)}function Xe(e){try{const t=e.getBoundingClientRect(),n=t.left+t.width/2,r=t.top+t.height/2,s={bubbles:!0,cancelable:!0,clientX:n,clientY:r,button:0,buttons:1,view:window};return e.dispatchEvent(new MouseEvent("mousedown",s)),e.dispatchEvent(new MouseEvent("mouseup",s)),e.dispatchEvent(new MouseEvent("click",s)),setTimeout(()=>{e.dispatchEvent(new MouseEvent("mousedown",s)),e.dispatchEvent(new MouseEvent("mouseup",s)),e.dispatchEvent(new MouseEvent("click",s)),e.dispatchEvent(new MouseEvent("dblclick",s))},80),!0}catch(t){return console.warn("[MoodScroll] double-tap failed:",t),!1}}}},X=(fe=(he=globalThis.browser)==null?void 0:he.runtime)!=null&&fe.id?globalThis.browser:globalThis.chrome;function J(i,...o){}const Ae={debug:(...i)=>J(console.debug,...i),log:(...i)=>J(console.log,...i),warn:(...i)=>J(console.warn,...i),error:(...i)=>J(console.error,...i)},Z=class Z extends Event{constructor(o,l){super(Z.EVENT_NAME,{}),this.newUrl=o,this.oldUrl=l}};$(Z,"EVENT_NAME",re("wxt:locationchange"));let ae=Z;function re(i){var o;return`${(o=X==null?void 0:X.runtime)==null?void 0:o.id}:content:${i}`}function De(i){let o,l;return{run(){o==null&&(l=new URL(location.href),o=i.setInterval(()=>{let m=new URL(location.href);m.href!==l.href&&(window.dispatchEvent(new ae(m,l)),l=m)},1e3))}}}const V=class V{constructor(o,l){$(this,"isTopFrame",window.self===window.top);$(this,"abortController");$(this,"locationWatcher",De(this));$(this,"receivedMessageIds",new Set);this.contentScriptName=o,this.options=l,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(o){return this.abortController.abort(o)}get isInvalid(){return X.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(o){return this.signal.addEventListener("abort",o),()=>this.signal.removeEventListener("abort",o)}block(){return new Promise(()=>{})}setInterval(o,l){const m=setInterval(()=>{this.isValid&&o()},l);return this.onInvalidated(()=>clearInterval(m)),m}setTimeout(o,l){const m=setTimeout(()=>{this.isValid&&o()},l);return this.onInvalidated(()=>clearTimeout(m)),m}requestAnimationFrame(o){const l=requestAnimationFrame((...m)=>{this.isValid&&o(...m)});return this.onInvalidated(()=>cancelAnimationFrame(l)),l}requestIdleCallback(o,l){const m=requestIdleCallback((...k)=>{this.signal.aborted||o(...k)},l);return this.onInvalidated(()=>cancelIdleCallback(m)),m}addEventListener(o,l,m,k){var b;l==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(b=o.addEventListener)==null||b.call(o,l.startsWith("wxt:")?re(l):l,m,{...k,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Ae.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:V.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(o){var b,A,I;const l=((b=o.data)==null?void 0:b.type)===V.SCRIPT_STARTED_MESSAGE_TYPE,m=((A=o.data)==null?void 0:A.contentScriptName)===this.contentScriptName,k=!this.receivedMessageIds.has((I=o.data)==null?void 0:I.messageId);return l&&m&&k}listenForNewerScripts(o){let l=!0;const m=k=>{if(this.verifyScriptStartedEvent(k)){this.receivedMessageIds.add(k.data.messageId);const b=l;if(l=!1,b&&(o!=null&&o.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",m),this.onInvalidated(()=>removeEventListener("message",m))}};$(V,"SCRIPT_STARTED_MESSAGE_TYPE",re("wxt:content-script-started"));let ie=V;function tt(){}function Q(i,...o){}const Be={debug:(...i)=>Q(console.debug,...i),log:(...i)=>Q(console.log,...i),warn:(...i)=>Q(console.warn,...i),error:(...i)=>Q(console.error,...i)};return(async()=>{try{const{main:i,...o}=Le,l=new ie("content",o);return await i(l)}catch(i){throw Be.error('The content script "content" crashed on startup!',i),i}})()}();
content;
